
<header class="navbar-fixed-top">
	<div class="container">
    	<div class="row">
        	<div class="header_top">
        		<div class="col-md-2">
            		<div class="logo_img">
						<a href="index.php"><img src="images/source4.gif" alt="logoimage" style="height:50px; width:90px;" ></a>
					</div>
				</div>
					
				<div class="col-md-10">
					<div class="menu_bar">	
						<nav role="navigation" class="navbar navbar-default">
							<div class="navbar-header">
                                <button id="menu_slide"  aria-controls="navbar" aria-expanded="false" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                  </button>
							   </div>
							   
							  <div class="collapse navbar-collapse" id="navbar">
                            
									<ul class="nav navbar-nav">
									  <li><a href="index.php" class="js-target-scroll"><b>Home</b></a></li>
									   <li><a href="index.php#about" class="js-target-scroll"><b>About Us</b></a></li>
									  <li><a href="index.php#services" class="js-target-scroll"><b>Services</b></a></li>
									
									   <li><a href="index.php#specifications" class="js-target-scroll"><b>Specifications</b></a></li>
									  <li><a href="pricing.php" class="js-target-scroll"><b>Pricing</b></a></li>
									  <!--
									   <li><a href="index.php#customers" class="js-target-scroll"><b>Customers</b></a></li>
									   -->
									  <li><a href="index.php#testimonial" class="js-target-scroll"><b>Testimonial</b></a></li>
									 
									  <li><a href="index.php#contact" class="js-target-scroll"><b>Contact</b></a></li>
								
									</ul>      
                          		</div>
							  
							 
       			
						</nav>
					</div>
    	        </div>
			  
			  </div>
			</div>
		</div>
</header>
